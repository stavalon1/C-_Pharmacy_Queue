﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Queue_Pharmacy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Queue<int> customersList = new Queue<int>(); // תור של מספרים
        int customerIndex = 0;// יוצר את מספרי הלקוח
        int customerCounter;
        int customer;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnNewCustomer_Click(object sender, EventArgs e)
        {
            customerIndex++;
            customersList.Enqueue(customerIndex);
            customerCounter = customersList.Count();
            listCustomers.Items.Clear();
            foreach(int index in customersList)
            {
                listCustomers.Items.Add(index);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (customersList.Count() > 0)
            {
                customer = customersList.Dequeue();
                textBox1.Text = "Customer " + customer + " is been served.";
                listCustomers.Items.Clear();
                foreach (int index in customersList)
                {
                    listCustomers.Items.Add(index);
                }
            }
            if (customersList.Count() == 0)
                MessageBox.Show("התור הסתיים.", "סופר פארם", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (customersList.Count() > 0)
            {
                customer = customersList.Dequeue();
                textBox2.Text = "Customer " + customer + " is been served.";
                listCustomers.Items.Clear();
                foreach (int index in customersList)
                {
                    listCustomers.Items.Add(index);
                }
            }
            if (customersList.Count() == 0)
                MessageBox.Show("התור הסתיים.", "סופר פארם", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (customersList.Count() > 0)
            {
                customer = customersList.Dequeue();
                textBox3.Text = "Customer " + customer + " is been served.";
                listCustomers.Items.Clear();
                foreach (int index in customersList)
                {
                    listCustomers.Items.Add(index);
                }
            }
            if (customersList.Count() == 0)
                MessageBox.Show("התור הסתיים.", "סופר פארם", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
